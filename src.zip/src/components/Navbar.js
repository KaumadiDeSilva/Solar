import { Link } from 'react-router-dom'
import logo from '../assets/Company_Logo.png'

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm p-2 bg-white rounded">
    <div className="container-fluid px-8">
      <Link to="/"><img className="mx-5" src={logo} alt='logo' width={130} height={80}/></Link>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ms-auto">
          <li className="nav-item mx-3">
            <Link to="/" className='navbar-items'><h4 className="nav-link active fs-3">Home</h4></Link>
          </li>
          <li className="nav-item mx-3">
            <Link to="/aboutus" className='navbar-items'><h4 className="nav-link fs-3">About Us</h4></Link>
          </li>
          <li className="nav-item mx-3">
            <Link to="/" className='navbar-items'><h4 className="nav-link fs-3">Contact Us</h4></Link>
          </li>
          <li className="nav-item mx-3">
            <Link to="/repairs" className='navbar-items'><h4 className="nav-link fs-3">Repair</h4></Link>
          </li>
        </ul>
        <div className="d-flex ms-auto">
          <div>
            <Link to="/login"><button type="button" class="btn btn-home mx-1">Login</button></Link>
            <Link to="/signup"><button type="button" class="btn btn-home mx-1">Signup</button></Link>
          </div>
        </div>
      </div>
    </div>
    </nav>
  )
}

export default Navbar