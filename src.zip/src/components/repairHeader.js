import '../cssModels/repairHeader.css';

function Header() {
  return (
    <div className="Header">
      <p>Repair Service</p>
     
     
    </div>
    

    
  );
}

export default Header;
