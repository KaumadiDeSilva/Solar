import { BrowserRouter, Routes, Route } from 'react-router-dom'

// pages & components
import NewRepairform from './pages/NewRepairform'
import RepairTable from './pages/RepairTable'
import EditRepair from './pages/EditRepair'
import NavBar from './components/Navbar'
import Home from './pages/repairHome'

function App() {

  return (
      <BrowserRouter>
      <NavBar/>
          <Routes>
          <Route 
              path="/repairs"
              element={<RepairTable />}
            />
            <Route 
              path="/repair/:id"
              element={<EditRepair />}
            />
            <Route 
              path="/add"
              element={<NewRepairform />}
            />
            <Route 
              path="/"
              element={<Home />}
            />
          </Routes>
      </BrowserRouter>
  );
}

export default App;
