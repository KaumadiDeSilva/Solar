import React from "react";
import homeimage from '../assets/solar_home_2.jpg'

const repairHome = () => {
    
    return (
        <div className='container my-5'>
          <div className="col-md-12 mx-auto">
          <div class="row">
            <div class="col">
              <h1>Innovate Solar</h1>
              <h1>Solutions For Your </h1>
              <h1>Home</h1>
            </div>
            <div class="col">
              <img src={homeimage} className='rounded mt-5' alt='homeimage'/>
              <div className='home-shape'></div>
            </div>
          </div>
          <div class="row mt-5">
            <div class="col-md-5">
              <span className='fs-5'>Our Experts will help make your home eco-friendly and entirely self sufficient</span>
            </div>
          </div>
            <div class="col-md-5 mt-5">
              <button type="button" class="btn btn-home btn-lg">Get Started</button>
            </div>
          </div>
        </div>
    )

}

export default repairHome