import React from "react";
import Header from "../components/repairHeader"

const Rcustomer = () => {

    return (

        <div>

        <div><Header /></div>

        <div id="container1">

        <div id="header2" class="repairheader2">
            <h1 id="header2">How can we help you today?</h1>
        </div>

        <div id="parainfo1" class="repairPara1">
            <p id="p1">Contact us the pioneer solar power company in Sri Lanka with greatest service and find out more about our solutions.</p>
        </div>

        <div id="para1" class="addreepara2">
            <p id="p2"><b>St. Anthony’s (Pvt) Ltd </b></p>
            <p id="p2">No. 513, Sri Sangaraja Mawatha, </p>
            <p id="p2">Colombo 10,</p> 
            <p id="p2">Sri Lanka.</p>
        </div>

        <div id="para1" class="info">
            <p id="p2"><b>Hotline</b>: +94 777 919 123 / +94 11 5 225521</p>
            <p id="p2"><b>Fax</b> : +94 11 5 225521</p>
            <p id="p2"><b> Email</b>: btech@solarpower.lk</p>

        </div>

        </div>

        <div id="container2">

        <div id="header3" class="repairheader3">
            <p id="header3">Place your repair request here!!</p>
        </div>

        <div id="divform1" class="customerform">
        <form>

        

        <div class="form-group">
        <label for="exampleInputname">Your Name</label>
        <input type="text" class="form-control" id="exampleInputname1" placeholder="Your Name"/>
        </div>

        <div class="form-group">
        <label for="exampleInputemail">Your email Address</label>
        <input type="text" class="form-control" id="exampleInputemail1" placeholder="Your email"/>
        </div>

        <div class="form-group">
        <label for="exampleInputnumber">Your phone Number</label>
        <input type="text" class="form-control" id="exampleInputnum1" placeholder="Your Number"/>
        </div>

        <div class="form-group">
        <label for="exampleInputmsg">Your massege</label>
        <input type="text" class="form-control" id="exampleInputmsg1" placeholder="Your massege"/>
        </div>

        

        <button type="submit" class="btn btn-primary">Submit</button>

        </form>

            
         </div>


        </div>

        </div>
    )
}

export default Rcustomer